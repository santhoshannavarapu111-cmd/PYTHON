const $ = (selector) => document.querySelector(selector);
const state = { records: [], total: 0 };
const produceIcons = { Tomato: "🍅", Onion: "🧅", Potato: "🥔", "Green chilli": "🌶️", Banana: "🍌", "Leafy greens": "🥬", Okra: "🥒", "Red chilli": "🌶️", Carrot: "🥕", Brinjal: "🍆" };
const titleByView = { dashboard: ["Overview", "Welcome back, grower.", "A clear picture of the prices you’re tracking."], records: ["Price records", "Your price notebook.", "Every market visit, neatly in one place."], insights: ["Price insights", "Understand your market.", "Compare the prices you’ve recorded over time."], data: ["Import & export", "Your data, your way.", "Bring in a spreadsheet or take your records with you."] };

function money(value) { return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(Number(value) || 0); }
function shortDate(value) { if (!value) return "—"; return new Date(`${value}T00:00:00`).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }); }
function unitLabel(value) { return value === "kg" ? "kg" : value; }
function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]); }
function setNotice(text, kind = "success") { const node = $("#notice"); node.textContent = text; node.className = `notice${kind === "success" ? "" : ` ${kind}`}`; node.hidden = false; clearTimeout(setNotice.timer); setNotice.timer = setTimeout(() => node.hidden = true, 6500); }
function grouped(records, keyFn) { const map = new Map(); for (const r of records) { const key = keyFn(r); if (!map.has(key)) map.set(key, []); map.get(key).push(r); } return map; }
function average(rows) { return rows.length ? rows.reduce((sum, r) => sum + Number(r.price), 0) / rows.length : 0; }
function iconFor(name) { return produceIcons[name] || "🌱"; }

function tableRows(records, showNotes = false) {
  return records.map(r => `<tr><td><div class="produce-cell"><span class="produce-icon">${iconFor(r.produce)}</span>${escapeHTML(r.produce)}</div></td><td class="market-cell">${escapeHTML(r.market)}</td><td class="date-cell">${shortDate(r.date)}</td><td class="price-cell">${money(r.price)} <span class="qty-cell">/ ${escapeHTML(unitLabel(r.unit))}</span></td><td class="qty-cell">${Number(r.quantity || 1).toLocaleString("en-IN")} ${escapeHTML(unitLabel(r.unit))}</td>${showNotes ? `<td class="note-cell" title="${escapeHTML(r.notes || "")}">${escapeHTML(r.notes || "—")}</td>` : ""}</tr>`).join("");
}

function renderDashboard() {
  const records = state.records;
  const produceNames = new Set(records.map(r => r.produce.toLowerCase()));
  const marketNames = new Set(records.map(r => r.market.toLowerCase()));
  $("#metric-count").textContent = state.total.toLocaleString("en-IN");
  $("#metric-produce").textContent = produceNames.size.toLocaleString("en-IN");
  $("#metric-markets").textContent = marketNames.size.toLocaleString("en-IN");
  $("#metric-average").textContent = records.length ? money(average(records)) : "₹—";
  $("#nav-count").textContent = state.total;
  const latest = [...records].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  $("#recent-rows").innerHTML = tableRows(latest);
  $("#recent-empty").hidden = records.length > 0;
  const byDate = grouped(records, r => r.date);
  const dates = [...byDate.keys()].sort().slice(-8);
  const max = Math.max(...dates.map(d => average(byDate.get(d))), 1);
  $("#chart").innerHTML = dates.map(d => { const value = average(byDate.get(d)); const height = Math.max(5, value / max * 100); return `<div class="chart-column"><div class="chart-bar" style="height:${height}%" data-tip="${shortDate(d)} · ${money(value)}"></div><span class="chart-label">${new Date(`${d}T00:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</span></div>`; }).join("");
  $("#chart-empty").hidden = records.length > 0;
  const byProduce = [...grouped(records, r => r.produce).entries()].sort((a, b) => b[1].length - a[1].length).slice(0, 4);
  const maxCount = Math.max(...byProduce.map(([, rows]) => rows.length), 1);
  $("#produce-mix").innerHTML = byProduce.map(([name, rows], i) => `<div class="mix-item"><div class="mix-item-head"><span>${iconFor(name)} &nbsp;${escapeHTML(name)}</span><span>${rows.length} ${rows.length === 1 ? "entry" : "entries"}</span></div><div class="mix-track"><div class="mix-fill" style="width:${rows.length / maxCount * 100}%"></div></div></div>`).join("");
  $("#mix-empty").hidden = records.length > 0;
}

function updateFilters() {
  const currentProduce = $("#produce-filter").value, currentMarket = $("#market-filter").value;
  const produce = [...new Set(state.records.map(r => r.produce))].sort((a, b) => a.localeCompare(b));
  const markets = [...new Set(state.records.map(r => r.market))].sort((a, b) => a.localeCompare(b));
  $("#produce-filter").innerHTML = '<option value="">All produce</option>' + produce.map(v => `<option>${escapeHTML(v)}</option>`).join("");
  $("#market-filter").innerHTML = '<option value="">All markets</option>' + markets.map(v => `<option>${escapeHTML(v)}</option>`).join("");
  $("#produce-filter").value = produce.includes(currentProduce) ? currentProduce : "";
  $("#market-filter").value = markets.includes(currentMarket) ? currentMarket : "";
}

function renderInsights() {
  const records = state.records;
  const byProduce = [...grouped(records, r => r.produce).entries()].map(([name, rows]) => ({ name, rows, avg: average(rows), unit: rows[0]?.unit })).sort((a, b) => b.avg - a.avg).slice(0, 8);
  const max = Math.max(...byProduce.map(x => x.avg), 1);
  $("#compare-chart").innerHTML = byProduce.map(x => `<div class="compare-row"><span class="compare-name" title="${escapeHTML(x.name)}">${iconFor(x.name)} ${escapeHTML(x.name)}</span><div class="compare-track"><div class="compare-fill" style="width:${x.avg / max * 100}%"></div></div><span class="compare-value">${money(x.avg)} / ${escapeHTML(x.unit)}</span></div>`).join("");
  $("#compare-empty").hidden = records.length > 0;
  const byMarket = [...grouped(records, r => `${r.market}|||${r.unit}`).entries()].map(([key, rows]) => ({ market: key.split("|||")[0], unit: key.split("|||")[1], rows, avg: average(rows) })).sort((a, b) => a.market.localeCompare(b.market));
  $("#market-comparison").innerHTML = byMarket.map(x => `<div class="market-card"><span>${escapeHTML(x.market)} · ${escapeHTML(x.unit)}</span><b>${money(x.avg)}</b><small>Average across ${x.rows.length} ${x.rows.length === 1 ? "entry" : "entries"}</small></div>`).join("");
  $("#market-empty").hidden = records.length > 0;
  const byUnit = [...grouped(records, r => r.unit).entries()];
  const latest = records.length ? [...records].sort((a, b) => b.date.localeCompare(a.date))[0].date : null;
  const first = records.length ? [...records].sort((a, b) => a.date.localeCompare(b.date))[0].date : null;
  $("#insight-summary").innerHTML = `<div class="summary-line"><span>Total entries</span><b>${records.length}</b></div><div class="summary-line"><span>Produce tracked</span><b>${new Set(records.map(r => r.produce.toLowerCase())).size}</b></div><div class="summary-line"><span>Markets compared</span><b>${new Set(records.map(r => r.market.toLowerCase())).size}</b></div><div class="summary-line"><span>Units recorded</span><b>${byUnit.map(([u]) => escapeHTML(u)).join(", ") || "—"}</b></div><div class="summary-line"><span>Date range</span><b>${first ? `${shortDate(first)} – ${shortDate(latest)}` : "—"}</b></div>`;
}

async function loadRecords() {
  const params = new URLSearchParams();
  if ($("#search").value.trim()) params.set("q", $("#search").value.trim());
  if ($("#produce-filter").value) params.set("produce", $("#produce-filter").value);
  if ($("#market-filter").value) params.set("market", $("#market-filter").value);
  const response = await fetch("/api/records");
  if (!response.ok) throw new Error("Could not load your local notebook.");
  const payload = await response.json();
  state.records = payload.records;
  state.total = payload.total;
  renderDashboard(); updateFilters(); renderInsights();
  // The dashboard and insight cards always use the full notebook. Filters only
  // narrow the table below.
  const filterParams = new URLSearchParams();
  if ($("#search").value.trim()) filterParams.set("q", $("#search").value.trim());
  if ($("#produce-filter").value) filterParams.set("produce", $("#produce-filter").value);
  if ($("#market-filter").value) filterParams.set("market", $("#market-filter").value);
  const filteredResponse = await fetch(`/api/records?${filterParams}`);
  const filtered = await filteredResponse.json();
  $("#all-rows").innerHTML = tableRows(filtered.records, true);
  $("#records-count").textContent = `${filtered.records.length} ${filtered.records.length === 1 ? "entry" : "entries"}`;
  $("#records-empty").hidden = filtered.records.length > 0;
}

function setView(view) {
  const selected = titleByView[view] ? view : "dashboard";
  document.querySelectorAll(".view").forEach(node => node.classList.toggle("active", node.id === `view-${selected}`));
  document.querySelectorAll(".nav-link").forEach(node => node.classList.toggle("active", node.dataset.view === selected));
  const [crumb, title, subtitle] = titleByView[selected];
  $("#crumb-current").textContent = crumb; $("#page-title").textContent = title; $("#page-subtitle").textContent = subtitle;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll(".nav-link").forEach(link => link.addEventListener("click", e => { e.preventDefault(); location.hash = link.dataset.view; setView(link.dataset.view); }));
window.addEventListener("hashchange", () => setView(location.hash.slice(1)));
$("#search").addEventListener("input", () => { clearTimeout(loadRecords.timer); loadRecords.timer = setTimeout(() => loadRecords().catch(err => setNotice(err.message, "error")), 160); });
$("#produce-filter").addEventListener("change", () => loadRecords().catch(err => setNotice(err.message, "error")));
$("#market-filter").addEventListener("change", () => loadRecords().catch(err => setNotice(err.message, "error")));

const dialog = $("#add-dialog");
function openDialog() { const dateInput = $("#add-form [name=date]"); const today = new Date().toISOString().slice(0, 10); dateInput.max = today; dateInput.value = today; $("#form-error").hidden = true; dialog.showModal(); }
$("#open-add").addEventListener("click", openDialog);
$("#close-add").addEventListener("click", () => dialog.close());
$("#cancel-add").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => { if (event.target === dialog) dialog.close(); });
$("#add-form").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget; const submit = $("#save-record"); submit.disabled = true; submit.textContent = "Saving…";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/records", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not save this entry.");
    dialog.close(); form.reset(); await loadRecords(); setView("dashboard");
    setNotice(result.warning || `${result.record.produce} price saved to your local notebook.` , result.warning ? "warning" : "success");
  } catch (err) { const box = $("#form-error"); box.textContent = err.message; box.hidden = false; }
  finally { submit.disabled = false; submit.innerHTML = 'Save record <span>→</span>'; }
});

$("#csv-file").addEventListener("change", async event => {
  const file = event.target.files[0]; if (!file) return;
  const resultNode = $("#import-result"); resultNode.textContent = "Checking CSV rows…";
  try {
    const response = await fetch("/api/import.csv", { method: "POST", headers: { "Content-Type": "text/csv; charset=utf-8" }, body: await file.text() });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Import failed.");
    let message = `${result.imported} ${result.imported === 1 ? "record" : "records"} added.`;
    if (result.errors.length) message += `\n${result.errors.length} row(s) skipped:\n` + result.errors.slice(0, 5).map(row => `Row ${row.row}: ${row.error}`).join("\n") + (result.errors.length > 5 ? "\nMore errors are available by correcting the CSV and importing again." : "");
    resultNode.textContent = message; await loadRecords();
  } catch (err) { resultNode.textContent = err.message; }
  finally { event.target.value = ""; }
});

setView(location.hash.slice(1) || "dashboard");
loadRecords().catch(err => setNotice(err.message, "error"));
