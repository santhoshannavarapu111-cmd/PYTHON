"""Farm Produce Price Notebook - local, dependency-free web application."""

from __future__ import annotations

import csv
import io
import json
import mimetypes
import re
import threading
import uuid
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "records.json"
STATIC_DIR = ROOT / "static"
DATA_LOCK = threading.Lock()
MAX_BODY = 2_000_000
UNITS = {"kg", "dozen", "bunch", "piece", "litre"}


def read_records() -> list[dict]:
    """Read the local notebook, recovering cleanly from a missing/bad file."""
    with DATA_LOCK:
        try:
            raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return []
            return [row for row in raw if isinstance(row, dict)]
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return []


def write_records(records: list[dict]) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with DATA_LOCK:
        temporary = DATA_FILE.with_suffix(".tmp")
        temporary.write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.replace(DATA_FILE)


def validate_record(payload: dict) -> tuple[dict | None, str | None]:
    """Normalize and validate one user or CSV supplied record."""
    produce = str(payload.get("produce", "")).strip()
    market = str(payload.get("market", "")).strip()
    unit = str(payload.get("unit", "")).strip().lower()
    raw_date = str(payload.get("date", "")).strip()
    if not produce or len(produce) > 60 or not re.fullmatch(r"[\w ,()'-]+", produce, re.UNICODE):
        return None, "Enter a produce name using letters, numbers, spaces, commas, apostrophes, or hyphens (60 characters max)."
    if not market or len(market) > 80:
        return None, "Enter a market name (80 characters max)."
    if unit not in UNITS:
        return None, "Choose kg, dozen, bunch, piece, or litre as the unit."
    try:
        parsed_date = date.fromisoformat(raw_date)
    except ValueError:
        return None, "Enter a valid date in YYYY-MM-DD format."
    if parsed_date > date.today():
        return None, "The price date cannot be in the future."
    try:
        price = float(payload.get("price"))
        quantity = int(payload.get("quantity") or 1)
    except (TypeError, ValueError):
        return None, "Price must be a number and quantity must be a whole number."
    if not (0 < price <= 1_000_000):
        return None, "Price must be greater than ₹0 and no more than ₹10,00,000 per unit."
    if not (1 <= quantity <= 100_000):
        return None, "Quantity must be between 1 and 100,000 units."
    notes = str(payload.get("notes", "")).strip()[:240]
    return {
        "id": str(uuid.uuid4()),
        "date": raw_date,
        "produce": produce,
        "market": market,
        "unit": unit,
        "price": round(price, 2),
        "quantity": quantity,
        "notes": notes,
    }, None


def json_response(handler: BaseHTTPRequestHandler, data: object, status: int = 200) -> None:
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


class NotebookHandler(BaseHTTPRequestHandler):
    server_version = "ProduceNotebook/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_BODY:
            raise ValueError("Upload is too large (maximum 2 MB).")
        return self.rfile.read(length)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/records":
            records = read_records()
            params = parse_qs(parsed.query)
            query = params.get("q", [""])[0].strip().casefold()
            produce_filter = params.get("produce", [""])[0].strip().casefold()
            market_filter = params.get("market", [""])[0].strip().casefold()
            result = [row for row in records if
                      (not query or query in " ".join(str(row.get(k, "")) for k in ("produce", "market", "notes")).casefold()) and
                      (not produce_filter or str(row.get("produce", "")).casefold() == produce_filter) and
                      (not market_filter or str(row.get("market", "")).casefold() == market_filter)]
            result.sort(key=lambda row: (row.get("date", ""), row.get("produce", "")), reverse=True)
            return json_response(self, {"records": result, "total": len(records)})
        if path == "/api/export.csv":
            records = read_records()
            output = io.StringIO(newline="")
            writer = csv.DictWriter(output, fieldnames=["date", "produce", "market", "unit", "price", "quantity", "notes"])
            writer.writeheader()
            writer.writerows({key: row.get(key, "") for key in writer.fieldnames} for row in records)
            return self.send_download(output.getvalue().encode("utf-8-sig"), "produce-price-records.csv", "text/csv; charset=utf-8")
        if path == "/api/export.json":
            body = (json.dumps(read_records(), indent=2, ensure_ascii=False) + "\n").encode("utf-8")
            return self.send_download(body, "produce-price-records.json", "application/json; charset=utf-8")
        if path == "/api/export.md":
            records = sorted(read_records(), key=lambda row: row.get("date", ""), reverse=True)
            lines = ["# Farm Produce Price Notebook", "", f"Generated: {datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z')}", "", "| Date | Produce | Market | Price / unit | Quantity |", "|---|---|---|---:|---:|"]
            lines += [f"| {r.get('date','')} | {r.get('produce','')} | {r.get('market','')} | ₹{float(r.get('price',0)):,.2f} / {r.get('unit','')} | {r.get('quantity',1)} |" for r in records]
            return self.send_download(("\n".join(lines) + "\n").encode("utf-8"), "produce-price-summary.md", "text/markdown; charset=utf-8")
        if path == "/" or path.startswith("/static/"):
            relative = "index.html" if path == "/" else path.removeprefix("/static/")
            requested = (STATIC_DIR / relative).resolve()
            if STATIC_DIR.resolve() not in requested.parents or not requested.is_file():
                return self.send_error(404)
            body = requested.read_bytes()
            mime = mimetypes.guess_type(requested.name)[0] or "application/octet-stream"
            return self.send_download(body, requested.name, mime + ("; charset=utf-8" if mime.startswith(("text/", "application/javascript")) else ""), attachment=False)
        return self.send_error(404)

    def send_download(self, body: bytes, filename: str, content_type: str, attachment: bool = True) -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            raw = self.read_body()
            if path == "/api/records":
                payload = json.loads(raw.decode("utf-8"))
                record, error = validate_record(payload)
                if error:
                    return json_response(self, {"error": error}, 400)
                records = read_records()
                same = [r for r in records if r.get("produce", "").casefold() == record["produce"].casefold() and r.get("unit") == record["unit"]]
                prices = [float(r["price"]) for r in same if "price" in r]
                warning = None
                if len(prices) >= 3:
                    baseline = sum(prices) / len(prices)
                    change = (record["price"] - baseline) / baseline if baseline else 0
                    if abs(change) >= 0.25:
                        direction = "above" if change > 0 else "below"
                        warning = f"This price is {abs(change) * 100:.0f}% {direction} the stored average for {record['produce']} ({record['unit']}). Check the entry if that seems unexpected."
                records.append(record)
                write_records(records)
                return json_response(self, {"record": record, "warning": warning}, 201)
            if path == "/api/import.csv":
                text = raw.decode("utf-8-sig")
                reader = csv.DictReader(io.StringIO(text))
                required = {"date", "produce", "market", "unit", "price"}
                headers = {h.strip().lower() for h in (reader.fieldnames or [])}
                if not required.issubset(headers):
                    return json_response(self, {"error": "CSV needs these headers: date, produce, market, unit, price. quantity and notes are optional."}, 400)
                # Map user header capitalization back to normalized field names.
                imported, errors = [], []
                for line_no, row in enumerate(reader, start=2):
                    normalized = {(key or "").strip().lower(): value for key, value in row.items()}
                    record, error = validate_record(normalized)
                    if error:
                        errors.append({"row": line_no, "error": error})
                    else:
                        imported.append(record)
                if imported:
                    write_records(read_records() + imported)
                return json_response(self, {"imported": len(imported), "errors": errors})
            return self.send_error(404)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            return json_response(self, {"error": str(exc) or "Could not read that request."}, 400)
        except OSError:
            return json_response(self, {"error": "Could not save the notebook file. Check that the project folder is writable."}, 500)


def main() -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        write_records([])
    host, port = "127.0.0.1", 8000
    server = ThreadingHTTPServer((host, port), NotebookHandler)
    print("Farm Produce Price Notebook is running.")
    print(f"Open http://{host}:{port} in your browser.")
    print("Keep this terminal open while you use the notebook. Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nNotebook stopped. Your records are saved locally.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
