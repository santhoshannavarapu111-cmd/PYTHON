# Farm Produce Price Notebook

A small local web app for recording farm produce prices, comparing markets, searching your notebook, and exporting your data. It uses Python's standard library only, so you do not need to install Flask or a database.

## What you need

- Windows 10/11 (the steps below use PowerShell)
- Python 3.10 or newer
- VS Code (recommended) with the Microsoft Python extension
- A modern browser such as Edge, Chrome, or Firefox

No internet connection or API key is needed to run the application. The app listens only on your own computer at `127.0.0.1`.

## Open and run in VS Code

1. Extract `PP_MINI.zip` to a folder, for example `C:\Users\YourName\Documents\PP_MINI`.
2. In VS Code, choose **File → Open Folder** and select the extracted `PP_MINI` folder.
3. Open **Terminal → New Terminal**. The terminal should start in the project folder.
4. Create a virtual environment (optional but recommended):

   ```powershell
   py -m venv .venv
   ```

5. Activate it in PowerShell:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use this for the current terminal only, then activate again:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   ```

6. Select the environment in VS Code: press **Ctrl+Shift+P**, run **Python: Select Interpreter**, and choose the one under `.venv`.
7. Start the app:

   ```powershell
   python app.py
   ```

8. Open **http://127.0.0.1:8000** in your browser. Keep the VS Code terminal open while using the app.
9. To stop the app, return to the terminal and press **Ctrl+C**. Your records are saved automatically.

If `py` is not recognized, install Python from python.org and enable **Add python.exe to PATH** during setup. Then reopen VS Code and use `python` instead of `py` in step 4.

## Use the notebook

- **Overview:** entry count, produce and market coverage, an indicative recent price chart, and recent entries.
- **Price records:** search across produce, market, and notes; narrow the list by produce or market.
- **Price insights:** compare recorded prices and market averages. Averages are grouped by unit for market comparisons; compare like units when interpreting prices.
- **Import & export:** import a CSV and export your notebook as CSV, JSON, or Markdown.
- **Add price record:** record a date, produce, market, unit, price, quantity, and optional note. The app validates entries and flags prices at least 25% above or below the stored average for the same produce and unit when there are at least three previous entries.

The app begins with 40 demonstration records. They are sample data, not live market quotations. You can remove demonstration entries by editing `data/records.json` while the server is stopped, or export a backup before changing the file. All data is stored in that JSON file.

## CSV import format

Required headers: `date,produce,market,unit,price`

Optional headers: `quantity,notes`

Dates use `YYYY-MM-DD`. Supported units are `kg`, `dozen`, `bunch`, `piece`, and `litre`. Invalid rows are skipped and reported; valid rows are saved. A starter file is available in `static/sample-import.csv`.

## Project files

```text
PP_MINI/
├── app.py                    # Local Python HTTP server, validation, storage, import/export
├── data/
│   └── records.json          # Local notebook and starter demonstration records
├── static/
│   ├── app.js                # Browser interactions and summary views
│   ├── index.html            # Browser interface
│   ├── sample-import.csv     # CSV import example
│   └── styles.css            # Responsive layout and styling
├── .gitignore
├── README.md
└── requirements.txt          # No third-party Python packages required
```

## Troubleshooting

- **Address already in use:** another app is using port 8000. Stop it, or change `port = 8000` near the bottom of `app.py` to an unused port and use that port in the browser address.
- **The browser cannot connect:** keep `python app.py` running and use exactly `http://127.0.0.1:8000`.
- **Records do not save:** make sure the extracted project folder is writable. The app writes `data/records.json` beside `app.py`.
- **It opens but looks unstyled:** confirm that `static/styles.css` and `static/app.js` are present in the extracted folder, then refresh the browser.

## Privacy

The app binds to the local loopback address and stores its records in the project folder. Anyone with access to that folder can read or change the JSON data file.
